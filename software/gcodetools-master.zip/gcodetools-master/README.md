gcodetools
==========

CAM extension for Inkscape to export paths to Gcode 

More info at http://www.cnc-club.ru/forum/viewtopic.php?t=35


License
==========
Inkscape and Gcodetools are licensed under GNU GPL.



Install
==========
Windows

Unpack and copy all the files to the following directory Program Files\Inkscape\share\extensions\ and restart inkscape.

Execute python create_inx.py to create all inx-files.

Linux

Unpack and copy all the files to the following directory /usr/share/inkscape/extensions/ and restart inkscape.

Execute python create_inx.py to create all inx-files.
